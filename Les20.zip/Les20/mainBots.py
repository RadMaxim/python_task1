from data import bot, idBot, types
@bot.message_handler(commands=["start"])
def handler_start(msg):
    keybord = types.InlineKeyboardMarkup(row_width=3)
    btn1 = types.InlineKeyboardButton(text="1", callback_data="1")
    btn2 = types.InlineKeyboardButton(text="2", callback_data="2")
    btn3 = types.InlineKeyboardButton(text="3", callback_data="3")
    keybord.add(btn1, btn2, btn3)
    bot.send_message(idBot, "Show btn",reply_markup=keybord)
bot.polling()
